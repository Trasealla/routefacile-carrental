import img4 from "../../assets/all-images/service-images/list-icon.svg";

const serviceData = [
  {
    id: 1,
    title: "Car Hire",
    icon: img4,
    desc: "We pride ourselves in always going the extra mile for our customers.",
  },

  {
    id: 2,
    title: "Car Sales",
    icon: img4,
    desc: "we sale the best luxury cars across the world at a competitive price. ",
  },

  {
    id: 3,
    title: "Hire a driver",
    icon: img4,
    desc: "you want to travel and fell confortable , our drivers are available. ",
  },
  {
    id: 4,
    title: "Safe & Sanitized Vehicles",
    icon: img4,
    desc: "you want to travel and fell confortable , our drivers are available. ",
  },
];

export default serviceData;
